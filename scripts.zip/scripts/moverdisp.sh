#!/bin/bash

# Ruta de la carpeta segura
carpeta_segura="ruta de la carpeta"

# Ruta de la carpeta del dispositivo
carpeta_dispositivo="ruta de la carpeta"

# Mover archivos de la carpeta segura a la carpeta del dispositivo
mv "$carpeta_segura"/* "$carpeta_dispositivo"

# Ejecutar el script final.sh
ruta del siguiente script